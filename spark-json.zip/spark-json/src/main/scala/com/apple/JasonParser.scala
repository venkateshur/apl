package com.apple

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{col, concat_ws, get_json_object, lit, regexp_replace}

object JasonParser extends App{
  val sparkSession: SparkSession = SparkSession
    .builder()
    .appName("json parser")
    .master("local[*]")
    .getOrCreate()

  val readJson = sparkSession.read.textFile("src/main/resources/sample.json").cache()
  //readJson.show()

  /*val parseJsonDf = readJson.select(
    regexp_replace(get_json_object(col("value"), "$.tableDataList[*]._id"), "\"", "").as("CASE_ID"),
    regexp_replace(get_json_object(col("value"), "$.tableDataList[*].type"), "\"", "").as("CASE_TYPE_CD"),
    regexp_replace(get_json_object(col("value"), "$.tableDataList[*].created"), "\"", "").as("CREATION_TS"),
    regexp_replace(get_json_object(col("value"), "$.tableDataList[*].lastModified"), "\"", "").as("ROW_LAST_MAINT_TS"),
    concat_ws("", lit("["),
      regexp_replace(get_json_object(col("value"), "$.tableDataList[*].symptom"), "\"", ""), lit("]"))
      .as("SYMPTOM"),
    regexp_replace(get_json_object(col("value"), "$.tableDataList[*].source"), "\"", "").as("PROVIDER"),
    regexp_replace(get_json_object(col("value"), "$.meta[*].SRC_OFFSET"), "\"", "").as("CASE_SEQ_NUMBER"))*/

  readJson.createOrReplaceTempView("readJson")
  val parseJsonDfExpr = sparkSession.sql("""select regexp_replace(get_json_object(value, '$.tableDataList[*]._id'), '\"', '') as CASE_ID,
        regexp_replace(get_json_object(value, '$.tableDataList[*].type'), '\"', '') as CASE_TYPE_CD,
        regexp_replace(get_json_object(value, '$.tableDataList[*].created'), '\"', '') as CREATION_TS,
        regexp_replace(get_json_object(value, '$.tableDataList[*].lastModified'), '\"', '') as ROW_LAST_MAINT_TS,
        concat_ws('', '[', regexp_replace(get_json_object(value, '$.tableDataList[*].symptom'), '\"', ''), '') as SYMPTOM,
        regexp_replace(get_json_object(value, '$.tableDataList[*].source'), '\"', '') as PROVIDER ,
        regexp_replace(get_json_object(value, '$.meta[*].SRC_OFFSET'), '\"', '') as CASE_SEQ_NUMBER from readJson""".stripMargin)

  //parseJsonDf.show(5, false)
  parseJsonDfExpr.show(5, false)
  sparkSession.stop()

}
